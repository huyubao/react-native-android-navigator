/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    TouchableOpacity
    } from 'react-native';

import Second from './second.js';
class main extends React.Component {
    constructor(props){
        super(props);
        this.state={
            name:'第一页',
        };
    }
    render() {
        return (
        <View style={styles.container}>
            <TouchableOpacity
                onPress={this._secondactivity.bind(this)}
                style={styles.button}>
                <Text style={styles.welcome}>
                    {this.state.name}
                </Text>
            </TouchableOpacity>
         </View>
);
}
    _secondactivity(){
        this.props.navigator.push({
            title:'second',
            component:Second,
        })
    }
}



const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F5FCFF',
    },
    button:{
        width:120,
        height:80,
        alignItems:'center',
        justifyContent:'center',
    },
    welcome: {
        fontSize: 20,
        textAlign: 'center',
        margin: 10,
        color:'#ff0000',
    },
    instructions: {
        textAlign: 'center',
        color: '#333333',
        marginBottom: 5,
    },
});

export default main;
