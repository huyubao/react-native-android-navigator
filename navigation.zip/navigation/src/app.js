/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Navigator
    } from 'react-native';

import Main from './main.js';

const defaultRoute = {
    component:Main
}

export default class navigation extends Component{
    _renderScene(route,navigator){
        let Component = route.component;
        return(
            <Component {...route.params} navigator={navigator}/>
        );
    }
    render(){
        return(
            <Navigator style={{flex:1}}
                initialRoute={defaultRoute}
                renderScene={this._renderScene}>
            </Navigator>
        );
    }
}
AppRegistry.registerComponent('navigation', () => navigation);