import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    TouchableOpacity
    } from 'react-native';

import Main from './main.js'

class second extends React.Component{

    _back(){
        this.props.navigator.pop()
    }

    render(){
        return(
            <View style={{flex:1,justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#F5FCFF',}}>

                <TouchableOpacity style={{
                width:120,
                height:80,
                alignItems:'center',
                justifyContent:'center',
                }}
                    onPress={this._back.bind(this)}>
                    <Text>第二页  返回上一页</Text>
                </TouchableOpacity>
            </View>
        );
    }
}

export default second;